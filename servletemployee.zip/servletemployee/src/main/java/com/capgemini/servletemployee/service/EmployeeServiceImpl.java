package com.capgemini.servletemployee.service;

import java.util.List;

import com.capgemini.servletemployee.dao.EmployeeDAO;
import com.capgemini.servletemployee.dao.EmployeeDAOImpl;
import com.capgemini.servletemployee.dto.EmployeeBean;

public class EmployeeServiceImpl implements EmployeeService {
	EmployeeDAO empdao=new EmployeeDAOImpl();

	public EmployeeBean getEmployeeByid(int Id) {
		
		return empdao.getEmployeeByid(Id);
	}

	public boolean addEmployee(EmployeeBean bean) {
		
		return empdao.addEmployee(bean);
	}

	public boolean updateEmployee(EmployeeBean bean) {
		
		return empdao.updateEmployee(bean);
	}

	public boolean deleteEmployee(int Id) {
		
		return empdao.deleteEmployee(Id);
	}

	public List<EmployeeBean> getAllEmployees() {
		
		return null;
	}

	public EmployeeBean authenticate(int empId, String password) {
				return empdao.authenticate(empId, password);
	}

}
